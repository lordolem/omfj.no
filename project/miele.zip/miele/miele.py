#!/usr/bin/python

import requests
import sys

class bcolors:
    HEADER = '\033[4m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    BGPURPLE = '\033[45m'
    BGCYAN = '\033[44m'
    ENDC = '\033[0m'

headers = {
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/plain, */*',
    'Authorization': 'Bearer D0-ZZRUTGuBqFXJYPaxARVzTzhgCDdzkpi7p1v0grcHqLs9ZWhSNDmceumbpDfxq2KJ4BDn2tHvygmziX8qu1-NDqpqSW-ipQg0Ndw8jRThDiQ_Wf06MWp306yqBiuBm8inc8i_YyuMX2G7osDwwTsR0IJTqZOCYjRyzfrA39UoZYrGDmfRvuU9P37bFyLUUbQaO3jS9q2Fn0qxIq3EzWKUB0eKuSZ_TX7xSALjSDjzu09BsRxMZ5bqjp27-3UndchUGVogc10-5HmUHae5xNWdS3_aQVTi4pCbawXmrdOENcVtoDQMJDti_y0LIqNbeNak1eT33sLgvZg8MR1eN4_mL1mMfe1CnOhvTxXvNrxB60ECy3-j1mI-R1qloiOprV6YHeco-SX1cf-KtY53yN2jwWd1bv0Hb6s2KA_vvLVtRtenOUo7pF8rLhdYceF7sfVR_YWBV9qFV90744XZdXYeqV63gUPAfwK-9NIfmwssTc0sigYUA7PL-y_VUmEWZLxmBLk99jVe-iS1dmqINc-ZTtqIkovL0weyzESP38-cqTuxlWYSYXXCF-iyOznaN5voWAiYtbI7fpny4JcvC9gTqGilClO8aLwfY9OB02MItjhZMDW6EhFuzBY2bIaqQMhbUCCj5BviCzXDwPpt_Kr4WZkRWD4xYFWVtYdSLQiXYLPjCEwrOvCWtbtU7Yhg4Al_4TeNEl9Ex1fC5g4OcgV-yOokZ3POWD9f5rBX3NAnH2j5w56mGv3JWQE-naIp6JYVX2P0ALRkoFyQHRHqgKWIaVs77QwNOBsmZtb4GHT10EtW3zS2GFz3sp150NqyU7BG4RECI04X3Fjhao_NeJeGoya_CVdBczqUORlz5-p3izLM_AIYM9Cq_oL1e_HY4galaZu1YpYJZyGiS8J630xtZwDkSJKHmnBTnsdfbrAmFCyp7',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36',
    'Sec-GPC': '1',
    'Origin': 'https://mielelogic.com',
    'Sec-Fetch-Site': 'same-site',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://mielelogic.com/',
    'Accept-Language': 'en-US,en;q=0.9',
}

params = (
    ('language', 'en'),
)

def get_data(bulding_id):
    if bulding_id == "52":
        url_id = "9126"
    elif bulding_id == "54":
        url_id = "9127"
    else:
        url_id = "9127"
    
    response = requests.get(f'https://api.mielelogic.com/v3/Country/NO/Laundry/{url_id}/laundrystates', headers=headers, params=params)
    data = response.json()
    machines = [i for i in data['MachineStates']]

    return machines

try:
    machines = get_data(sys.argv[1])
    building = sys.argv[1]
except IndexError:
    machines = get_data(54)
    building = "54"

print(f"{bcolors.HEADER}-- Grønneviksøren {building} --{bcolors.ENDC}")

for machine in machines:
    unitName = machine['UnitName']
    machineSymbol = machine['MachineSymbol']
    machineColor = machine['MachineColor']
    text1 = machine['Text1']
    text2 = machine['Text2']
    
    if machineSymbol == 0:
        machineType=f"{bcolors.BGPURPLE}Washer${bcolors.ENDC}"
    else:
        machineType=f"{bcolors.BGCYAN}Dyrer${bcolors.ENDC}"

    if machineColor == 2:
        print(f"{bcolors.WARNING}{unitName}{bcolors.ENDC} {machineType}: {bcolors.WARNING}{text1}{text2}{bcolors.ENDC}")
    else:
        print(f"{bcolors.OKGREEN}{unitName}{bcolors.ENDC} {machineType}: {bcolors.OKGREEN}{text1}{text2}{bcolors.ENDC}")
        