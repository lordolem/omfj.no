#!/usr/bin/env bash

# laundryState52=$(curl 'https://api.mielelogic.com/v3/Country/NO/Laundry/9126/laundrystates?language=en' \
#   -H 'Connection: keep-alive' \
#   -H 'Accept: application/json, text/plain, */*' \
#   -H 'Authorization: Bearer D0-ZZRUTGuBqFXJYPaxARVzTzhgCDdzkpi7p1v0grcHqLs9ZWhSNDmceumbpDfxq2KJ4BDn2tHvygmziX8qu1-NDqpqSW-ipQg0Ndw8jRThDiQ_Wf06MWp306yqBiuBm8inc8i_YyuMX2G7osDwwTsR0IJTqZOCYjRyzfrA39UoZYrGDmfRvuU9P37bFyLUUbQaO3jS9q2Fn0qxIq3EzWKUB0eKuSZ_TX7xSALjSDjzu09BsRxMZ5bqjp27-3UndchUGVogc10-5HmUHae5xNWdS3_aQVTi4pCbawXmrdOENcVtoDQMJDti_y0LIqNbeNak1eT33sLgvZg8MR1eN4_mL1mMfe1CnOhvTxXvNrxB60ECy3-j1mI-R1qloiOprV6YHeco-SX1cf-KtY53yN2jwWd1bv0Hb6s2KA_vvLVtRtenOUo7pF8rLhdYceF7sfVR_YWBV9qFV90744XZdXYeqV63gUPAfwK-9NIfmwssTc0sigYUA7PL-y_VUmEWZLxmBLk99jVe-iS1dmqINc-ZTtqIkovL0weyzESP38-cqTuxlWYSYXXCF-iyOznaN5voWAiYtbI7fpny4JcvC9gTqGilClO8aLwfY9OB02MItjhZMDW6EhFuzBY2bIaqQMhbUCCj5BviCzXDwPpt_Kr4WZkRWD4xYFWVtYdSLQiXYLPjCEwrOvCWtbtU7Yhg4Al_4TeNEl9Ex1fC5g4OcgV-yOokZ3POWD9f5rBX3NAnH2j5w56mGv3JWQE-naIp6JYVX2P0ALRkoFyQHRHqgKWIaVs77QwNOBsmZtb4GHT10EtW3zS2GFz3sp150NqyU7BG4RECI04X3Fjhao_NeJeGoya_CVdBczqUORlz5-p3izLM_AIYM9Cq_oL1e_HY4galaZu1YpYJZyGiS8J630xtZwDkSJKHmnBTnsdfbrAmFCyp7' \
#   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36' \
#   -H 'Sec-GPC: 1' \
#   -H 'Origin: https://mielelogic.com' \
#   -H 'Sec-Fetch-Site: same-site' \
#   -H 'Sec-Fetch-Mode: cors' \
#   -H 'Sec-Fetch-Dest: empty' \
#   -H 'Referer: https://mielelogic.com/' \
#   -H 'Accept-Language: en-US,en;q=0.9' \
#   --compressed -s)

# laundryState54=$(curl 'https://api.mielelogic.com/v3/Country/NO/Laundry/9127/laundrystates?language=en' \
#   -H 'Connection: keep-alive' \
#   -H 'Accept: application/json, text/plain, */*' \
#   -H 'Authorization: Bearer D0-ZZRUTGuBqFXJYPaxARVzTzhgCDdzkpi7p1v0grcHqLs9ZWhSNDmceumbpDfxq2KJ4BDn2tHvygmziX8qu1-NDqpqSW-ipQg0Ndw8jRThDiQ_Wf06MWp306yqBiuBm8inc8i_YyuMX2G7osDwwTsR0IJTqZOCYjRyzfrA39UoZYrGDmfRvuU9P37bFyLUUbQaO3jS9q2Fn0qxIq3EzWKUB0eKuSZ_TX7xSALjSDjzu09BsRxMZ5bqjp27-3UndchUGVogc10-5HmUHae5xNWdS3_aQVTi4pCbawXmrdOENcVtoDQMJDti_y0LIqNbeNak1eT33sLgvZg8MR1eN4_mL1mMfe1CnOhvTxXvNrxB60ECy3-j1mI-R1qloiOprV6YHeco-SX1cf-KtY53yN2jwWd1bv0Hb6s2KA_vvLVtRtenOUo7pF8rLhdYceF7sfVR_YWBV9qFV90744XZdXYeqV63gUPAfwK-9NIfmwssTc0sigYUA7PL-y_VUmEWZLxmBLk99jVe-iS1dmqINc-ZTtqIkovL0weyzESP38-cqTuxlWYSYXXCF-iyOznaN5voWAiYtbI7fpny4JcvC9gTqGilClO8aLwfY9OB02MItjhZMDW6EhFuzBY2bIaqQMhbUCCj5BviCzXDwPpt_Kr4WZkRWD4xYFWVtYdSLQiXYLPjCEwrOvCWtbtU7Yhg4Al_4TeNEl9Ex1fC5g4OcgV-yOokZ3POWD9f5rBX3NAnH2j5w56mGv3JWQE-naIp6JYVX2P0ALRkoFyQHRHqgKWIaVs77QwNOBsmZtb4GHT10EtW3zS2GFz3sp150NqyU7BG4RECI04X3Fjhao_NeJeGoya_CVdBczqUORlz5-p3izLM_AIYM9Cq_oL1e_HY4galaZu1YpYJZyGiS8J630xtZwDkSJKHmnBTnsdfbrAmFCyp7' \
#   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36' \
#   -H 'Sec-GPC: 1' \
#   -H 'Origin: https://mielelogic.com' \
#   -H 'Sec-Fetch-Site: same-site' \
#   -H 'Sec-Fetch-Mode: cors' \
#   -H 'Sec-Fetch-Dest: empty' \
#   -H 'Referer: https://mielelogic.com/' \
#   -H 'Accept-Language: en-US,en;q=0.9' \
#   --compressed -s)

# Colors
FG_RED="\e[91m"
FG_GREEN="\e[92m"
FG_YELLOW="\e[93m"
FG_BLUE="\e[94m"

BG_RED="\e[101m"
BG_GREEN="\e[102m"
BG_YELLOW="\e[103m"
BG_BLUE="\e[104m"
BG_CYAN="\e[106m"
BG_GRAY="\e[100m"

NC="\e[0m"
###########

function getLaundryState() {

  if [[ $1 == 52 ]]; then
    ID="9126"
  elif [[ $1 == 54 ]]; then
    ID="9127"
  fi

  laundryState=$(curl "https://api.mielelogic.com/v3/Country/NO/Laundry/$ID/laundrystates?language=en" \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json, text/plain, */*' \
  -H 'Authorization: Bearer D0-ZZRUTGuBqFXJYPaxARVzTzhgCDdzkpi7p1v0grcHqLs9ZWhSNDmceumbpDfxq2KJ4BDn2tHvygmziX8qu1-NDqpqSW-ipQg0Ndw8jRThDiQ_Wf06MWp306yqBiuBm8inc8i_YyuMX2G7osDwwTsR0IJTqZOCYjRyzfrA39UoZYrGDmfRvuU9P37bFyLUUbQaO3jS9q2Fn0qxIq3EzWKUB0eKuSZ_TX7xSALjSDjzu09BsRxMZ5bqjp27-3UndchUGVogc10-5HmUHae5xNWdS3_aQVTi4pCbawXmrdOENcVtoDQMJDti_y0LIqNbeNak1eT33sLgvZg8MR1eN4_mL1mMfe1CnOhvTxXvNrxB60ECy3-j1mI-R1qloiOprV6YHeco-SX1cf-KtY53yN2jwWd1bv0Hb6s2KA_vvLVtRtenOUo7pF8rLhdYceF7sfVR_YWBV9qFV90744XZdXYeqV63gUPAfwK-9NIfmwssTc0sigYUA7PL-y_VUmEWZLxmBLk99jVe-iS1dmqINc-ZTtqIkovL0weyzESP38-cqTuxlWYSYXXCF-iyOznaN5voWAiYtbI7fpny4JcvC9gTqGilClO8aLwfY9OB02MItjhZMDW6EhFuzBY2bIaqQMhbUCCj5BviCzXDwPpt_Kr4WZkRWD4xYFWVtYdSLQiXYLPjCEwrOvCWtbtU7Yhg4Al_4TeNEl9Ex1fC5g4OcgV-yOokZ3POWD9f5rBX3NAnH2j5w56mGv3JWQE-naIp6JYVX2P0ALRkoFyQHRHqgKWIaVs77QwNOBsmZtb4GHT10EtW3zS2GFz3sp150NqyU7BG4RECI04X3Fjhao_NeJeGoya_CVdBczqUORlz5-p3izLM_AIYM9Cq_oL1e_HY4galaZu1YpYJZyGiS8J630xtZwDkSJKHmnBTnsdfbrAmFCyp7' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36' \
  -H 'Sec-GPC: 1' \
  -H 'Origin: https://mielelogic.com' \
  -H 'Sec-Fetch-Site: same-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://mielelogic.com/' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --compressed -s)

  length=$(echo "$laundryState" | jq ".MachineStates" | jq "length")
  length=$((length-1))

  for i in $(seq 0 $length); do
    unitName=$(echo "$laundryState" | jq ".MachineStates[$i].UnitName")
    machineSymbol=$(echo "$laundryState" | jq ".MachineStates[$i].MachineSymbol")
    machineColor=$(echo "$laundryState" | jq ".MachineStates[$i].MachineColor")
    text1=$(echo "$laundryState"  | jq ".MachineStates[$i].Text1" | sed -e 's/\\n//g')
    text2=$(echo "$laundryState"  | jq ".MachineStates[$i].Text2" | sed -e 's/\\n//g')

    if [[ $machineSymbol == 0 ]]; then
      type="${BG_GRAY}Washer${NC}"
    else
      type="${BG_BLUE}Dyrer${NC}"
    fi

    if [[ $machineColor == 2 ]]; then
      echo -e "${FG_RED}$unitName ${NC}$type:-${FG_RED} $text1 $text2${NC}" | sed "s/\"//g"
    else
      echo -e "${FG_GREEN}$unitName ${NC}$type:-${FG_GREEN} $text1 $text2${NC}" | sed "s/\"//g"
    fi
  done
}

case "$1" in
  "help")
    echo "Usage: miele [52|54]"
    exit 0
    ;;
  "52")
    echo -e "${FG_GREEN}-- Grønneviksøren $1 --${NC}"
    getLaundryState 52 | column -t -s "-" 
    exit 0
    ;;
  "54")
    echo -e "${FG_GREEN}-- Grønneviksøren $1 --${NC}"
    getLaundryState 54 | column -t -s "-" 
    exit 0
    ;;
  *)
    echo -e "${FG_GREEN}-- Grønneviksøren 54 --${NC}"
    getLaundryState 54 | column -t -s "-" 
    exit 0
    ;;
esac
